"""Проверить, какая доля продолжений измеренной длины образует действительную короткую дорогу."""
from bisect import bisect_right
from itertools import accumulate
from random import Random

from .bridge_automaton import suffixes, transitions
from .interface import Move
from .paired_witness import open_step
from .pilot_automaton import Mode
from .resource_automaton import Service
from .route_witness import agrees, geometry
from .street_trunk import StreetTrunkReserve


def thin(paths, limit, rng):
    """Ограничить число путей, сохранив суммарный вес и пропорции при повторном отборе."""
    if len(paths) <= limit:
        return paths
    states = list(paths)
    cumulative = list(accumulate(paths.values()))
    step = cumulative[-1] / limit
    offset = rng.random() * step
    kept = {}
    for i in range(limit):
        j = min(bisect_right(cumulative, offset + i * step), len(states) - 1)
        state = states[j]
        kept[state] = kept.get(state, 0.) + step
    return kept


def path_fractions(view, readings, old, prior, sites, options, kind):
    memory = view.memory
    width = len(memory[0])
    index = lambda p: p[1] * width + p[0]
    origin = index(view.position)
    goal = view.position[0] + view.dx, view.position[1] + view.dy
    known = sum(1 << i for i, c in enumerate("".join(memory)) if c not in "#?") | (1 << index(goal))
    marks = [sum(1 << index(p) for p in group) for group in sites]
    shifts, adjacent = geometry(width, len(memory))
    service = Service((Mode.FUEL, Mode.REPAIR)[kind], (view.fuel, view.health)[kind], readings[kind], sites[kind])
    moves = tuple(Move)
    for restricted in (True, False):
        neighbors, turns = transitions(memory, restricted)
        layers = {t: values.copy() for t, values in suffixes(view, service, old[kind], restricted)}
        starts = [(move, i, int(neighbors[i, origin])) for i, move in enumerate(moves) if move in options]
        starts = [(move, i, q) for move, i, q in starts if layers[1][i, q] > 0.]
        if starts:
            break
    constraints = [(origin, readings)]
    if prior is not None:
        constraints.append((index(prior), old))
    def consistent(mask):
        for p, gauges in constraints:
            active = [i for i, d in enumerate(gauges) if d is not None]
            if not active:
                continue
            required = {active.index(kind)} if p == origin and kind in active else set()
            if not agrees(mask, shifts, p, [marks[i] for i in active], [gauges[i] for i in active], required):
                return False
        return True

    rng = Random(42)
    chances = {}
    for move, first, q in starts:
        seen = (1 << origin) | (1 << q)
        paths = {(q, first, seen, known | open_step(origin, q, move)): 1.}
        for t in range(1, service.distance):
            children = {}
            for (p, last, visited, opened), weight in paths.items():
                denominator = layers[t][last, p]
                for j, direction in enumerate(moves):
                    n = int(neighbors[j, p])
                    value = turns[last, j, p] * layers[t+1][j, n]
                    if not value or (visited >> n) & 1 or adjacent[n] & (visited ^ (1 << p)):
                        continue
                    state = n, j, visited | (1 << n), opened | open_step(p, n, direction)
                    children[state] = children.get(state, 0.) + weight * (value / denominator)
            paths = thin(children, 32, rng)
            if not paths:
                break
        chances[move] = sum(weight for (*_, mask), weight in paths.items() if consistent(mask))
    return chances


class PathParticles(StreetTrunkReserve):
    def rank_directions(self, view, readings, old, prior, sites, options, kind, default):
        raw = self.direction_votes(view, readings, old, prior, sites)[kind]
        factors = {}
        if 0 <= (view.fuel, view.health)[kind] - readings[kind] < 2:
            factors = path_fractions(view, readings, old, prior, sites, options, kind)
        if not any(factors.values()):
            return max(options, key=lambda m: (raw[m], m == default))
        mean = sum(factors.values()) / len(factors)
        return max(options, key=lambda m: (raw[m] * factors.get(m, mean), raw[m], m == default))
