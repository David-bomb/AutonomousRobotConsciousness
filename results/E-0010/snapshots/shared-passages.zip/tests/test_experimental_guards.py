import unittest
from dataclasses import replace
from importlib.util import find_spec

from maze.environment import Environment
from maze.interface import Move
from maze.levels import Level


@unittest.skipUnless(find_spec("scipy") and find_spec("numpy"), "Требуются библиотеки эксперимента E-0010")
class NavigationGuards(unittest.TestCase):
    def test_sensor_determines_hidden_gate_with_two_different_trip_lengths(self):
        from maze.deduced_roads import deductions
        memory=("#######","#...?F#","#.###.#","#R....#","#######")
        sites=(((5,1),),((1,3),))
        for length,terrain in ((4,"."),(8,"#")):
            inferred=deductions(memory,(1,1),(3,3),(length,2),None,(None,None),sites)
            self.assertEqual(inferred[1][4],terrain)
            self.assertEqual(memory[1][4],"?")

    def test_rotated_rectangular_memory_keeps_each_known_cell(self):
        from maze.symmetric_roads import oriented_grids
        memory=("abc","def")
        frames=oriented_grids(memory)
        self.assertEqual(len({grid for grid,*_ in frames}),8)
        for grid,(ox,oy),(ex,ey),(sx,sy) in frames:
            for y,row in enumerate(memory):
                for x,symbol in enumerate(row):
                    self.assertEqual(grid[oy+x*ey+y*sy][ox+x*ex+y*sx],symbol)

    def test_projected_trip_reaches_a_station_on_its_last_unit(self):
        from math import inf
        from maze.last_mission import trip_length
        sites=[("F",1),("R",3),("B",5)]
        fields=[[abs(i-p) for i in range(6)] for _,p in sites]
        self.assertEqual(trip_length(0,(1,3),sites,fields,{}),5)
        self.assertEqual(trip_length(0,(1,2),sites,fields,{}),inf)
        self.assertEqual(trip_length(0,(1,3),sites,fields,{"F":2}),inf)

    def test_last_unit_preserves_direct_finish(self):
        from maze.last_unit import surviving_moves
        level=Level.parse("проверка\n2 20\n#######\n#F.A.B#\n###.###\n#..R..#\n#######")
        view=replace(Environment(level).view,memory=level.grid)
        self.assertEqual(view.fuel,view.fuel_distance)
        self.assertEqual(surviving_moves(view,(None,None),Move.EAST),Move.EAST)
        self.assertEqual(surviving_moves(view,(None,None),Move.SOUTH),Move.WEST)

    def test_one_probe_spends_both_resources(self):
        from maze.fork_budget import chance
        self.assertEqual(chance(1,1,0,0),0.25)
        self.assertEqual(chance(1,1,0,2),0.5)
        self.assertEqual(chance(1,1,2,4),1.)

    def test_hypothetical_corner_obeys_physical_movement(self):
        from maze.route_witness import agrees,geometry
        shifts,_=geometry(3,3)
        floor=(1<<0)|(1<<4)|(1<<1)
        self.assertTrue(agrees(floor,shifts,0,(1<<4,1<<1),(2,1),{0,1}))
        self.assertFalse(agrees(floor,shifts,0,(1<<4,1<<1),(1,1),{0,1}))
        self.assertTrue(agrees(floor|(1<<3),shifts,0,(1<<4,1<<1),(1,1),{0,1}))
