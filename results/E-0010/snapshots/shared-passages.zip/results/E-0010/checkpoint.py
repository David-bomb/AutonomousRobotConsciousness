"""Снимок исходников и контрольных сумм полностью записанных серий."""
from argparse import ArgumentParser
from hashlib import sha256
import json
import platform
from zipfile import ZIP_DEFLATED,ZipFile

import numpy
import scipy

from bench import HERE,ROOT,SETS
from ledger import PARENTS


def digest(data):
    return sha256(data.replace(b"\r\n",b"\n")).hexdigest()


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("name")
    args=parser.parse_args()
    if not args.name.replace("-","").isalnum():
        parser.error("Имя снимка должно состоять из букв, цифр и дефиса")
    files=sorted((ROOT/"maze").glob("*.py"))+sorted(HERE.glob("*.py"))
    files.extend([ROOT/"scripts/audit_automaton.py",ROOT/"docs/experiments/E-0010-lineage.md",
                  ROOT/"tests/test_experimental_guards.py"])
    manifest=dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__,
                  maps={str(p.relative_to(ROOT).as_posix()):digest(p.read_bytes()) for p in SETS.values()},
                  sources={},runs={})
    for key in ("reserve",*PARENTS):
        path=HERE/f"{key}.jsonl"
        if not path.exists():
            continue
        data=path.read_bytes()
        if len(data.splitlines())==336:
            cases=[json.loads(l) for l in data.splitlines()]
            assert len({r["map"] for r in cases})==336
            manifest["runs"][key]=dict(parent=PARENTS.get(key),sha256_lf=digest(data),
                wins=[sum(r["split"]==s and r["status"]=="SUCCESS" for r in cases) for s in SETS])
    snapshots=HERE/"snapshots"
    snapshots.mkdir(exist_ok=True)
    with ZipFile(snapshots/f"{args.name}.zip","x",compression=ZIP_DEFLATED) as archive:
        for path in files:
            data=path.read_bytes()
            rel=path.relative_to(ROOT).as_posix()
            archive.writestr(rel,data)
            manifest["sources"][rel]=digest(data)
        archive.writestr("manifest.json",json.dumps(manifest,indent=2))
    with ZipFile(snapshots/f"{args.name}.zip") as archive:
        assert archive.testzip() is None
        for path,h in manifest["sources"].items():
            assert digest(archive.read(path))==h
    print(args.name,len(files),"исходных файлов,",len(manifest["runs"]),"полных серий")


if __name__=="__main__":
    main()
