"""Повтор физического запуска после изменений в общей части дерева контроллеров."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import json

from bench import AGENTS,HERE,cases,run_case
from compare import read


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("agent",choices=AGENTS)
    p.add_argument("--workers",type=int,default=2)
    args=p.parse_args()
    previous=read(args.agent)
    folder=HERE/"confirm"
    folder.mkdir(exist_ok=True)
    with (folder/f"{args.agent}.jsonl").open("x",encoding="utf8") as out, ProcessPoolExecutor(args.workers) as pool:
        for row in pool.map(run_case,((args.agent,c) for c in cases())):
            name=row["map"]
            if row!=previous[name]:
                raise ValueError(f"Повтор расходится на {name}")
            out.write(json.dumps(row,ensure_ascii=False)+"\n")
            out.flush()
    print(args.agent,len(previous),"точных повторов, включая каждую команду и счётчики режимов")


if __name__=="__main__":
    main()
