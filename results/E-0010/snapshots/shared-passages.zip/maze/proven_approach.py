"""Какие первые ходы ведут на кратчайший путь при любом допустимом месте выхода."""
from functools import lru_cache

from .frontier_automaton import _paths
from .frontier_reserve import _optimistic
from .grid import destination,wave
from .interface import Move
from .passage_automaton import exits
from .street_trunk import StreetTrunk


@lru_cache(maxsize=128)
def service_field(memory,sites):
    return {p:n for p,n,_ in wave(memory,sites)}


@lru_cache(maxsize=128)
def certified(memory,position,measured,old,prior,sites):
    if not measured or not sites:
        return frozenset(),frozenset()
    physical={m:q for m in Move if (q:=destination(memory,position,m)) is not None}
    known=service_field(memory,sites)
    # Уже открытая дорога ровно измеренной длины подтверждает каждый её первый ход.
    if known.get(position)==measured:
        sure=frozenset(m for m,q in physical.items() if known.get(q)==measured-1)
        return sure,frozenset(physical)
    optimistic=service_field(_optimistic(memory),sites)
    opened=_paths(memory,position)
    before=_paths(memory,prior) if prior is not None and old is not None else {}
    possible=set()
    certain=None
    for q,(dx,dy),t,first,_ in exits(memory,position):
        p=q[0]-dx,q[1]-dy
        left=measured-t
        if not optimistic.get(q,float("inf"))<=left<=known.get(q,float("inf")):
            continue
        if opened.get(q,(float("inf"),))[0]<t:
            continue
        if old is not None and min(before.get(q,(float("inf"),))[0]+left,
                                   before.get(p,(float("inf"),))[0]+1+left)<old:
            continue
        options=set(first)
        possible.update(options)
        certain=options if certain is None else certain & options
    return frozenset(certain or ()),frozenset(possible)


class ProvenApproach(StreetTrunk):
    def rank_directions(self,view,readings,old,prior,sites,options,kind,default):
        sure,possible=certified(view.memory,view.position,readings[kind],old[kind],prior,sites[kind])
        retained={m:v for m,v in options.items() if m in (sure or possible)}
        return super().rank_directions(view,readings,old,prior,sites,retained or options,kind,default)
