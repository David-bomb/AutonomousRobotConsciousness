"""Сколько предполагаемых планировок поддерживало действие в первом расхождении."""
import json

from bench import HERE, MOVES, cases, clear_episode_caches
from compare import PhysicalRoutes, read, transition
from maze.environment import Environment
from maze.room_roads import RoomPassages, room_votes
from maze.street_trunk import StreetTrunk


class ObservedRoom(RoomPassages):
    capture = False
    evidence = None

    def rank_directions(self,view,readings,old,prior,sites,options,kind,default):
        chosen=super().rank_directions(view,readings,old,prior,sites,options,kind,default)
        if self.capture:
            scores=room_votes(view,readings,old,prior,sites,True)
            self.evidence=dict(service="FR"[kind],default=default.name,
                               options=[m.name for m in options],
                               weights={m.name:float(w) for m,w in scores[kind].items()} if scores else {})
        return chosen


def measure(level,base,child,i):
    clear_episode_caches()
    env=Environment(level)
    bots=StreetTrunk(),ObservedRoom()
    for j in range(i+1):
        bots[1].capture = j==i
        moves=tuple(bot.choose(env.view) for bot in bots)
        assert all(move==MOVES[int(row["actions"][j])] for move,row in zip(moves,(base,child)))
        if j<i:
            assert moves[0]==moves[1]
            env.step(moves[0])
    routes=PhysicalRoutes(level)
    state=env.position,env.fuel,env.health
    return dict(step=i+1,pos=env.position,stocks=[env.fuel,env.health],
                lengths=[env.view.fuel_distance,env.view.repair_distance],
                moves=[m.name for m in moves],safe=[transition(routes,state,m,env.limit-i-1) for m in moves],
                evidence=bots[1].evidence)


def main():
    path=HERE/"room-observations.jsonl"
    saved={r["map"]:r for line in path.read_bytes().splitlines() if (r:=json.loads(line))} if path.exists() else {}
    base=read("street-trunk")
    children={r["map"]:r for line in (HERE/"room-passages.jsonl").read_bytes().splitlines() if (r:=json.loads(line))}
    with path.open("a",encoding="utf8") as out:
        for split,name,_,_,level in cases():
            if name not in children:
                continue
            old,new=base[name],children[name]
            diff=next((i for i,(a,b) in enumerate(zip(old["actions"],new["actions"])) if a!=b),None)
            if diff is None:
                assert old["actions"]==new["actions"] and old["status"]==new["status"]
                continue
            statuses=[old["status"],new["status"]]
            if name in saved:
                assert saved[name]["step"]==diff+1 and saved[name]["statuses"]==statuses
                continue
            row=dict(map=name,split=split,statuses=statuses,**measure(level,old,new,diff))
            out.write(json.dumps(row,ensure_ascii=False)+"\n")
            out.flush()
    print("Проверено записанных поездок",len(children),flush=True)


if __name__=="__main__":
    main()
