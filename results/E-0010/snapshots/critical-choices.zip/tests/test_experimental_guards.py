import unittest
from dataclasses import replace
from importlib.util import find_spec

from maze.environment import Environment
from maze.interface import Move
from maze.levels import Level


@unittest.skipUnless(find_spec("scipy") and find_spec("numpy"), "Требуются библиотеки эксперимента E-0010")
class NavigationGuards(unittest.TestCase):
    def test_smallest_detour_requires_a_unique_compatible_direction(self):
        from maze.proven_approach import smallest_detour
        lengths = {Move.WEST: 8, Move.EAST: 5, Move.NORTH: 11}
        self.assertEqual(smallest_detour(lengths, set(), {Move.WEST, Move.EAST}), Move.WEST)
        self.assertIsNone(smallest_detour(lengths, {Move.EAST}, set(lengths)))
        self.assertIsNone(smallest_detour({Move.WEST: 8, Move.EAST: 8}, set(), set()))
        # Второй датчик показывает путь вдвое длиннее нижней оценки.
        # При показании 16 первый ход с оценкой 8 объясняет этот обход.
        self.assertEqual(smallest_detour(lengths, set(), set(lengths), (16, 10, 5)), Move.WEST)

    def test_first_window_keeps_the_fuel_detour_and_stops_at_first_observation(self):
        from maze.first_window import window_arrivals
        level = Level.parse("Выезд с возможной дозаправкой\n4 20\nF.A.....B")
        view = replace(Environment(level).view, memory=("F.....?.B",))
        arrivals = {(a.point,a.length,a.fuel,a.health,a.first) for a in window_arrivals(view)}
        self.assertEqual(arrivals, {((5,0),3,1,17,Move.EAST), ((5,0),7,95,13,Move.WEST)})

    def test_onward_support_includes_direct_finish_from_first_station(self):
        from maze.shortcut_reserve import onward_support
        level = Level.parse("После ремонта прямо к финишу\n6 4\nB..R..A..F")
        view = replace(Environment(level).view, memory=level.grid)
        # До R и оттуда до B по три хода. Путь между F и R длиннее
        # оставшегося второго запаса после любого из первых заездов.
        self.assertEqual(onward_support(view,(None,None)),1)
        self.assertEqual(onward_support(replace(view,fuel=5),(None,None)),0)

    def test_first_stop_can_be_the_farther_workshop(self):
        from maze.known_landing import FirstLanding, first_legs, known_first_stops, supported_stop
        level = Level.parse("Две мастерские\n6 4\nB..R..A.R......F")
        view = replace(Environment(level).view, memory=level.grid)
        sites = [((3,0),"R"), ((8,0),"R"), ((15,0),"F")]
        # Подъезд к F проходит через ближнюю мастерскую. Для финиша после
        # ремонта на дальнем пути хватает ровно трёх оставшихся единиц топлива.
        legs = first_legs(view.memory,view.position,level.goal)
        self.assertEqual({(p,d) for p,d,_ in legs}, {((3,0),3), ((8,0),2)})
        choices = known_first_stops(view,sites,level.goal)
        best = supported_stop(view,level.goal,choices)
        self.assertEqual((best.point,best.move), ((3,0),Move.WEST))
        self.assertEqual(FirstLanding().ongoing_stop(view,level.goal,sites[:2]),best)

    def test_translated_routes_obey_the_actual_map_boundary(self):
        import numpy as np
        from maze.grid import wave
        from maze.translated_paths import landscape, routes_to
        roads,depth,jump,boxes=landscape(4,1)
        width=roads.shape[1]
        checked=set()
        crops=[(0,0,9,9),(1,1,5,5),(3,2,4,5)]
        crops.extend((0,y,9,1) for y in range(1,8))
        for x,y,w,h in crops:
            grid=tuple("".join("." if c else "#" for c in r) for r in roads[y:y+h,x:x+w])
            points=[(i,j) for j,row in enumerate(grid) for i,v in enumerate(row) if v=="."]
            for start in points:
                paths={p:(d,m) for p,d,m in wave(grid,[start])}
                sources=np.full(len(points),(y+start[1])*width+x+start[0])
                targets=np.array([(y+b)*width+x+a for a,b in points])
                crop=tuple(np.full(len(points),v) for v in (x,y,x+w,y+h))
                lengths,steps=routes_to(sources,targets,depth,jump,boxes,crop)
                for i,p in enumerate(points):
                    d,m=paths.get(p,(10**6,None))
                    self.assertEqual(lengths[i],d)
                    checked.add(d==10**6)
                    if m:
                        self.assertEqual(steps[i],m.value[0]+width*m.value[1])
        self.assertEqual(checked,{False,True})

    def test_required_stock_for_a_relay_and_last_unit_at_goal(self):
        from maze.conditional_mission import required_after_stop
        from maze.stretch_sortie import tolerates
        sites = [("R",0),("F",55),("B",105)]
        fields = [[abs(i-q) for i in range(106)] for _,q in sites]
        import numpy as np
        need = required_after_stop(sites, np.array(fields))
        self.assertEqual(need[1], 50)
        self.assertEqual(need[0], float("inf"))
        self.assertTrue(tolerates((3,5), (3,6), ((0,2),(2,0)), ("F","B"), 1.))
        self.assertFalse(tolerates((3,4), (3,6), ((0,2),(2,0)), ("F","B"), 1.))

    def test_relay_station_rejoins_a_renewable_pair(self):
        from maze.renewable_routes import renewable_routes
        from maze.excursion_automaton import shelters
        memory = ("#" * 95, "#R" + "." * 39 + "F" + "." * 51 + "R#", "#" * 95)
        stops = (((1, 1), "R"), ((41, 1), "F"), ((93, 1), "R"))
        self.assertNotIn((93, 1), shelters(memory, stops))
        self.assertEqual(renewable_routes(memory, stops)[(93, 1)], ("R", 52))

    def test_flow_and_conditional_readings_on_a_known_corridor(self):
        from maze.passage_flow import flows
        from maze.implied_turn import support
        memory = ("#######", "#F...R#", "#######")
        sites = (((1, 1),), ((5, 1),))
        origin, target, goal = (3, 1), (2, 1), (4, 1)
        flow = flows(memory, origin, goal, sites[0], 2)
        self.assertGreater(flow[Move.WEST], 0.)
        self.assertEqual(flow.get(Move.EAST, 0.), 0.)
        self.assertEqual(support(memory, origin, target, goal, (2, 2), (1, 3), sites), 1.)
        self.assertEqual(support(memory, origin, target, goal, (2, 2), (1, 1), sites), 0.)

    def test_sensor_determines_hidden_gate_with_two_different_trip_lengths(self):
        from maze.deduced_roads import deductions
        memory=("#######","#...?F#","#.###.#","#R....#","#######")
        sites=(((5,1),),((1,3),))
        for length,terrain in ((4,"."),(8,"#")):
            inferred=deductions(memory,(1,1),(3,3),(length,2),None,(None,None),sites)
            self.assertEqual(inferred[1][4],terrain)
            self.assertEqual(memory[1][4],"?")

    def test_rotated_rectangular_memory_keeps_each_known_cell(self):
        from maze.symmetric_roads import oriented_grids
        memory=("abc","def")
        frames=oriented_grids(memory)
        self.assertEqual(len({grid for grid,*_ in frames}),8)
        for grid,(ox,oy),(ex,ey),(sx,sy) in frames:
            for y,row in enumerate(memory):
                for x,symbol in enumerate(row):
                    self.assertEqual(grid[oy+x*ey+y*sy][ox+x*ex+y*sx],symbol)

    def test_projected_trip_reaches_a_station_on_its_last_unit(self):
        from math import inf
        from maze.last_mission import trip_length
        sites=[("F",1),("R",3),("B",5)]
        fields=[[abs(i-p) for i in range(6)] for _,p in sites]
        self.assertEqual(trip_length(0,(1,3),sites,fields,{}),5)
        self.assertEqual(trip_length(0,(1,2),sites,fields,{}),inf)
        self.assertEqual(trip_length(0,(1,3),sites,fields,{"F":2}),inf)

    def test_last_unit_preserves_direct_finish(self):
        from maze.last_unit import surviving_moves
        level=Level.parse("проверка\n2 20\n#######\n#F.A.B#\n###.###\n#..R..#\n#######")
        view=replace(Environment(level).view,memory=level.grid)
        self.assertEqual(view.fuel,view.fuel_distance)
        self.assertEqual(surviving_moves(view,(None,None),Move.EAST),Move.EAST)
        self.assertEqual(surviving_moves(view,(None,None),Move.SOUTH),Move.WEST)

    def test_one_probe_spends_both_resources(self):
        from maze.fork_budget import chance
        self.assertEqual(chance(1,1,0,0),0.25)
        self.assertEqual(chance(1,1,0,2),0.5)
        self.assertEqual(chance(1,1,2,4),1.)

    def test_visible_fork_reduces_chance_of_reaching_service_without_a_probe(self):
        from maze.leg_survival import continuation_chance
        # Дороги 0-1-2-3 до станции и ложный выход 1-4.
        roads = [{1}, {0, 2, 4}, {1, 3}, {2}, {1}]
        field = [3, 2, 1, 0, 3]
        unknown = [0] * len(roads)
        self.assertEqual(continuation_chance(roads.__getitem__, field, unknown)(0, 1), .5)
        self.assertEqual(continuation_chance(roads.__getitem__, field, field)(0, 1), 1.)

    def test_hypothetical_corner_obeys_physical_movement(self):
        from maze.route_witness import agrees,geometry
        shifts,_=geometry(3,3)
        floor=(1<<0)|(1<<4)|(1<<1)
        self.assertTrue(agrees(floor,shifts,0,(1<<4,1<<1),(2,1),{0,1}))
        self.assertFalse(agrees(floor,shifts,0,(1<<4,1<<1),(1,1),{0,1}))
        self.assertTrue(agrees(floor|(1<<3),shifts,0,(1<<4,1<<1),(1,1),{0,1}))
