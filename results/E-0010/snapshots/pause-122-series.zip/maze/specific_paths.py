"""Выбирать способ проверки подхода по числу станций, совместимых с показанием."""
from .frontier_reserve import _lengths, _optimistic
from .path_particles import particle_choice
from .service_exit_paths import StationUsefulPaths


class SpecificPaths(StationUsefulPaths):
    def rank_directions(self, view, readings, old, prior, sites, options, kind, default):
        measured = readings[kind]
        if measured is not None and 0 <= (view.fuel, view.health)[kind] - measured < 2:
            lower = _lengths(_optimistic(view.memory), view.position)
            plausible = [p for p in sites[kind] if lower.get(p, float("inf")) <= measured]
            if len(plausible) == 1:
                raw = self.direction_votes(view, readings, old, prior, sites)[kind]
                return particle_choice(view, readings, old, prior, sites, options, kind, default, raw)
        return super().rank_directions(view, readings, old, prior, sites, options, kind, default)
