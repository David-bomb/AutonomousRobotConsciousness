"""Физические прогоны. Показания среды для разбора записываются после решения."""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from hashlib import sha256
import json
from pathlib import Path
import sys
import importlib

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from maze.datasets import load_split
from maze.environment import Environment, Status
from maze.excursion_automaton import Excursion, RangeExcursion
from maze.frontier_reserve import ReserveFrontier
from maze.interface import Move
from maze.leg_automaton import AnchorOrder
from maze.levels import Level
from maze.passage_automaton import JointPassage, Passage

AGENTS = {"reserve": ReserveFrontier, "anchor": AnchorOrder, "passage": Passage,
          "joint": JointPassage, "excursion": Excursion, "range": RangeExcursion,
          "roads": "road_hypotheses.RoadHypotheses", "range-roads": "road_hypotheses.RangeRoads",
          "bridge": "bridge_automaton.BridgePassage", "relay": "relay_automaton.Relay",
          "corridor": "bridge_automaton.CorridorBridge", "cells": "cell_hypotheses.CellRoads",
          "fork-budget": "fork_budget.ForkBudget", "outer": "outer_automaton.OuterRange",
          "outer-service": "outer_automaton.OuterService", "coupled": "road_hypotheses.CoupledRoads",
          "return": "road_hypotheses.ReturnEvidence", "witness": "route_witness.WitnessRoads",
          "streets": "pattern_roads.PatternRoads", "last-unit": "last_unit.LastUnit",
          "shared": "shared_approach.SharedApproach", "consensus": "shared_approach.Consensus",
          "homing": "homing_automaton.Homing", "probe-order": "probe_order.ProbeOrder",
          "mission": "mission_automaton.MissionRoads", "marked-streets": "pattern_roads.MarkedStreets",
          "many-streets": "pattern_roads.ManyStreets", "mixed-streets": "pattern_roads.MixedStreets",
          "trunk": "shared_trunk.SharedTrunk", "trunk-reserve": "shared_trunk.TrunkReserve",
          "street-trunk": "street_trunk.StreetTrunk","exact-worlds":"exact_worlds.ExactWorlds",
          "street-consensus":"calibrated_routes.StreetConsensus","calibrated":"calibrated_routes.CalibratedRoutes",
          "all-approaches":"pattern_roads.AllApproaches","insured-approaches":"pattern_roads.InsuredApproaches",
          "survey-streets":"sortie_automaton.SurveyStreets","scouting-sortie":"sortie_automaton.ScoutingSortie",
          "terminal-streets":"sortie_automaton.TerminalStreets","texture-cells":"texture_roads.TextureCells",
          "adaptive-trunk":"street_trunk.AdaptiveTrunk","stable-streets":"pattern_roads.StableStreets"}
SETS = {"I": ROOT/"results/ARC-dot/source/ARC-stress-100/maps.jsonl",
        "II": ROOT/"results/E-0007/fresh.jsonl", "III": ROOT/"results/E-0009/fresh.jsonl",
        "val": ROOT/"maze/datasets/val.jsonl"}
MOVES = tuple(Move)


def cases():
    for split, path in SETS.items():
        if split == "val":
            for c in load_split("val"):
                yield split, c.name, str(c.stage), split, c.level
        else:
            for line in path.read_bytes().splitlines():
                r = json.loads(line)
                level = Level.parse("\n".join([r["name"], f'{r["fuel"]} {r["health"]}', *r["grid"]]))
                yield split, r["name"], r["tier"], r["family"], level


def run_case(job):
    agent, (split, name, tier, family, level) = job
    env = Environment(level)
    factory = AGENTS[agent]
    if isinstance(factory, str):
        module, name_in_module = factory.split(".")
        factory = getattr(importlib.import_module("maze."+module),name_in_module)
    bot = factory()
    actions = bytearray()
    modes = Counter()
    while env.status == Status.RUNNING:
        move = bot.choose(env.view)
        modes[bot.activity] += 1
        actions.append(48 + MOVES.index(move))
        env.step(move)
    return dict(split=split, map=name, tier=tier, family=family, status=env.status.name,
                steps=env.steps, refuels=env.refuels, repairs=env.repairs,
                actions=actions.decode("ascii"), modes=modes)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("agent", choices=AGENTS)
    p.add_argument("output", type=Path)
    p.add_argument("--workers", type=int, default=6)
    p.add_argument("--resume", action="store_true", help="дописать отсутствующие карты собственной серии")
    args = p.parse_args()
    selected = list(cases())
    assert Counter(c[0] for c in selected) == {"I": 100, "II": 100, "III": 100, "val": 36}
    assert len(set(c[1] for c in selected)) == len(selected)
    hashes = {k: sha256(v.read_bytes().replace(b"\r\n", b"\n")).hexdigest() for k,v in SETS.items()}
    print(args.agent, hashes, flush=True)
    if args.resume:
        if args.output.stem != args.agent:
            p.error("Для возобновления имя файла должно совпадать с агентом")
        finished = [json.loads(line) for line in args.output.read_bytes().splitlines()]
        done = {(r["split"],r["map"],r["tier"],r["family"]) for r in finished}
        assert len(done) == len(finished) and done <= {c[:4] for c in selected}
        assert all(r["steps"] == len(r["actions"]) and r["status"] in Status.__members__ for r in finished)
        selected = [c for c in selected if c[:4] not in done]
    with args.output.open("a" if args.resume else "x", encoding="utf8", newline="\n") as output, ProcessPoolExecutor(args.workers) as pool:
        futures = [pool.submit(run_case, (args.agent, case)) for case in selected]
        for i, future in enumerate(as_completed(futures), 1):
            output.write(json.dumps(future.result(), ensure_ascii=False)+"\n")
            output.flush()
            if i % 50 == 0:
                print(args.agent, i, flush=True)


if __name__ == "__main__":
    main()
