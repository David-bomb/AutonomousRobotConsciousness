"""Сводка полностью измеренных ветвей и список изменений на каждой карте."""
from collections import Counter
import argparse
import json
from statistics import mean
import subprocess
import sys

from bench import HERE, SETS
from compare import read

PARENTS = {"anchor":"reserve", "passage":"reserve", "joint":"passage", "roads":"reserve",
           "excursion":"reserve", "range":"excursion", "range-roads":"range",
           "bridge":"passage", "relay":"range-roads", "corridor":"bridge", "cells":"range-roads",
           "fork-budget":"range-roads", "outer":"range-roads", "outer-service":"outer",
           "coupled":"range-roads", "return":"coupled", "witness":"range-roads", "streets":"range-roads",
           "last-unit":"range-roads", "shared":"range-roads", "consensus":"range-roads",
           "homing":"range-roads", "probe-order":"range-roads", "mission":"range-roads",
           "marked-streets":"streets", "many-streets":"marked-streets","mixed-streets":"many-streets",
           "trunk":"range-roads","trunk-reserve":"trunk","street-trunk":"marked-streets",
           "exact-worlds":"marked-streets","street-consensus":"streets","calibrated":"street-consensus",
           "all-approaches":"marked-streets","insured-approaches":"all-approaches",
           "survey-streets":"streets","scouting-sortie":"streets","terminal-streets":"streets",
           "texture-cells":"cells","adaptive-trunk":"street-trunk","stable-streets":"streets"}


def lines(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compare-missing",action="store_true",help="добавить парные журналы готовых серий")
    args=parser.parse_args()
    root = read("reserve")
    for split,old in zip(SETS,("known1","known2","fresh","val")):
        archive = lines(HERE.parent/"E-0009"/f"{old}-episodes.jsonl")
        for r in archive:
            current = root[r["map"]]
            assert current["split"] == split
            assert all(current[k]==r["agents"]["reserve"][k] for k in ("status","steps","refuels","repairs"))
    reference = {r["map"]:r["parent_loss"] for r in lines(HERE/"reserve--anchor.jsonl") if "parent_loss" in r}
    for row in lines(HERE.parent/"E-0008/trace.jsonl"):
        old,new = row["critical"],reference[row["map"]]
        assert old["step"]==new["step"] and old["move"]==new["move"] and set(old["viable"])==set(new["viable"])
    data = {"reserve":root}
    for key in PARENTS:
        path = HERE/f"{key}.jsonl"
        if path.exists() and len(lines(path)) == len(root):
            data[key] = read(key)
    if args.compare_missing:
        for child,parent in PARENTS.items():
            if child in data and parent in data and not (HERE/f"{parent}--{child}.jsonl").exists():
                subprocess.run([sys.executable,"-B","-X","utf8",str(HERE/"compare.py"),parent,child],check=True)
    def fmt_rate(a):
        wins = [r["steps"] for r in a if r["status"]=="SUCCESS"]
        return f"{len(wins)} ({mean(wins):.1f})" if wins else "0"
    doc = ["# E-0010. Парные исходы всех законченных серий","",
           "В скобках указано среднее число ходов среди финишей данного автомата. "
           "Все 336 записей корня совпали с E-0009 по исходу, ходам и обоим счётчикам обслуживания. "
           "У независимой поклеточной проверки E-0008 и поиска по станциям E-0010 совпали "
           "номер первого необратимого хода, команда и все спасающие направления на 90 отказах.","",
           "| Автомат | Родитель | I из 100 | II из 100 | III из 100 | val из 36 |",
           "|---|---|---:|---:|---:|---:|"]
    for key,rows in data.items():
        cells = [fmt_rate([r for r in rows.values() if r["split"]==split]) for split in SETS]
        doc.append("| "+" | ".join([f"[`{key}`]({key}.jsonl)",PARENTS.get(key,"—"),*cells])+" |")
    doc += ["","## По сравнению с непосредственным родителем","",
            "Указаны все приобретённые и потерянные финиши. Изменившаяся поездка имеет хотя бы одну другую физическую команду. "
            "В колонке общих финишей даны количества быстрее / столько же / медленнее у потомка.","",
            "| Потомок | Набор | Изменились поездки | Приобретены | Потеряны | Общие финиши |",
            "|---|---|---:|---|---|---|"]
    for child,parent in PARENTS.items():
        if child not in data or parent not in data:
            continue
        for split in SETS:
            a,b = data[parent],data[child]
            names = sorted(k for k,v in b.items() if v["split"]==split)
            win = lambda r:r["status"]=="SUCCESS"
            gains = [k for k in names if win(b[k]) and not win(a[k])]
            losses = [k for k in names if win(a[k]) and not win(b[k])]
            changed = sum(a[k]["actions"]!=b[k]["actions"] for k in names)
            delta = Counter((b[k]["steps"]>a[k]["steps"])-(b[k]["steps"]<a[k]["steps"])
                            for k in names if win(a[k]) and win(b[k]))
            detail = HERE/f"{parent}--{child}.jsonl"
            name = f"[`{child}`]({detail.name})" if detail.exists() and len(lines(detail))==336 else child
            doc.append(f"| {name} | {split} | {changed} | {', '.join(gains) or '—'} | "
                       f"{', '.join(losses) or '—'} | {delta[-1]} / {delta[0]} / {delta[1]} |")
    doc += ["","## Исход и число ходов на каждой карте","",
            "Ф означает финиш, Т — исчерпано топливо, И — исчерпана исправность, Л — лимит ходов.","",
            "| Набор | Карта | "+" | ".join(data)+" |","|---|---|"+"---:|"*len(data)]
    labels = dict(SUCCESS="Ф", EMPTY="Т", BROKEN="И", LIMIT="Л")
    for split in SETS:
        for key in sorted(k for k,v in root.items() if v["split"]==split):
            results = [f"{labels[rows[key]['status']]} {rows[key]['steps']}" for rows in data.values()]
            doc.append("| "+" | ".join([split,key,*results])+" |")
    (HERE/"by-map.md").write_text("\n".join(doc)+"\n",encoding="utf8")
    print(", ".join(data))


if __name__=="__main__":
    main()
